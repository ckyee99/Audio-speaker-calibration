import streamlit as st
import sounddevice as sd
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy import signal
import io
import csv

# Setting up the Streamlit page configuration
st.set_page_config(page_title="Speaker Calibration Test Procedure", layout="wide")

# Loading the CSV file containing test procedures
@st.cache_data
def load_test_procedures():
    csv_content = """Item Number,Description of the Test,Setup,Expected Result,Remarks
1,"Microphone Calibration","Place Brüel & Kjær Type 4231 Sound Calibrator over Sennheiser MKH 416 microphone. Connect microphone to Zoom H4n Pro via XLR cable (Mogami Gold). Enable 48V phantom power on Zoom H4n. Record 1 kHz tone at 94 dB and 114 dB in Streamlit app.","Sensitivity within ±1 dB at 94 dB and 114 dB.","MKH 416 is not a measurement mic; expect slight deviation. Ensure phantom power is on. Recalibrate if interrupted."
2,"Background Noise Measurement","Position MKH 416 on K&M 26740 stand, 1 m from speaker, at tweeter height (1.2 m). Speaker off, room quiet. Record noise for 10 seconds in Streamlit app.","Background noise <30 dB SPL across 20 Hz to 15 kHz.","Minimize HVAC or traffic noise. Average over 10 seconds."
3,"On-Axis Frequency Response (Full Range)","Connect speaker to Crown XLi 800 via Mogami XLR. Position MKH 416 1 m from speaker, on-axis with tweeter. Play pink noise at 80 dB SPL via Streamlit app. Measure response with 1/12-octave smoothing.","Flat response (±3 dB) from 50 Hz to 15 kHz, gentle roll-off below 50 Hz.","Set Zoom H4n input level to ~5/100 to avoid clipping. Note baffle step at ~500 Hz."
4,"Low-Frequency Near-Field Response","Move MKH 416 to 5 cm from woofer cone center. Play swept sine wave (20 Hz to 200 Hz). Measure response in Streamlit app.","Response within ±3 dB down to 50 Hz, 12 dB/octave roll-off below.","Accounts for room effects. Adjust for baffle step using cabinet dimensions."
5,"Tweeter Near-Field Response","Position MKH 416 10 cm from tweeter center, on-axis. Play swept sine wave (1 kHz to 15 kHz). Measure response.","Flat response (±3 dB) from 2 kHz to 15 kHz.","Ensure precise alignment to avoid off-axis errors."
6,"Phase Response at Crossover","Position MKH 416 1 m from speaker, on-axis. Play swept sine wave (1 kHz to 5 kHz) covering crossover (e.g., 2.5 kHz). Measure phase.","Phase difference <30° at crossover frequency.","Adjust crossover if dips occur. Use Streamlit phase plot for analysis."
7,"Off-Axis Frequency Response (Horizontal)","Position MKH 416 1 m from speaker, at 30° and 60° horizontal angles. Play pink noise at 80 dB SPL. Measure response.","Smooth response, gradual roll-off above 8 kHz, no sharp dips.","Confirms spatial positioning at 2 m. Compare to on-axis."
8,"Off-Axis Frequency Response (Vertical)","Position MKH 416 1 m from speaker, at ±10° vertical angles. Play pink noise at 80 dB SPL. Measure response.","Smooth response with minimal crossover interference, ±3 dB variation.","Ensures balanced sound at 2 m."
9,"Group Delay Measurement","Play swept sine (20 Hz to 15 kHz). Measure group delay from impulse response with MKH 416 at 1 m.","Group delay <2 ms from 200 Hz to 15 kHz, increasing below 200 Hz.","Low delay ensures tight bass. Sealed cabinet preferred."
10,"Harmonic Distortion Measurement","Play swept sine (20 Hz to 15 kHz) at 90 dB SPL. Measure 2nd/3rd harmonic distortion with MKH 416 at 1 m.","Distortion <1% from 100 Hz to 10 kHz, <3% below 100 Hz.","High distortion indicates driver/cabinet issues. Test at multiple levels."
11,"Cumulative Spectral Decay (CSD)","Play short MLS signal. Measure CSD with MKH 416 at 1 m, on-axis.","No resonances above -30 dB after 1 ms, especially 1-3 kHz.","Identifies resonances. Adjust damping if ridges persist."
12,"Impedance Measurement","Connect speaker to Zoom H4n via impedance jig. Measure impedance across 20 Hz to 15 kHz.","Nominal impedance (e.g., 8 ohms), no dips below 6.4 ohms. Peaks at 50-100 Hz.","Confirms amplifier compatibility. Note resonance frequencies."
13,"Listening Window Response","Measure response at nine positions (±30° horizontal, ±10° vertical) around 1 m. Average in Streamlit app.","Flat response (±3 dB) with attenuated interference.","Ensures consistent sound at 2 m."
14,"Driver Interaction Check","Play pink noise and swept sine at crossover (e.g., 2.5 kHz). Measure response at 1 m.","No dips >3 dB at crossover, smooth transition.","Adjust crossover slope/phase if dips occur."
15,"Final Listening Test","Position speaker on K&M stand, listener at 2 m. Play reference tracks via Streamlit app. Assess balance, imaging, clarity.","Balanced sound, accurate imaging, no audible distortion.","Document impressions. Adjust EQ/crossover if needed."
"""
    try:
        df = pd.read_csv(io.StringIO(csv_content), quoting=csv.QUOTE_ALL, escapechar='\\')
        return df
    except pd.errors.ParserError as e:
        st.error(f"Failed to parse CSV: {e}")
        st.write("Please check the CSV content for formatting issues.")
        return pd.DataFrame()

# Load test procedures
test_procedures = load_test_procedures()
if test_procedures.empty:
    st.stop()

# Initializing session state for storing captured waveforms
if 'waveforms' not in st.session_state:
    st.session_state.waveforms = []
    st.session_state.colors = ['blue', 'red', 'green', 'orange']
    st.session_state.run_count = 0

# Check if Zoom H4n is connected
def is_audio_interface_connected():
    try:
        devices = sd.query_devices()
        return any('Zoom H4n' in device['name'] for device in devices)
    except Exception:
        return False

# Generating test signals
def generate_pink_noise(fs, duration):
    n = int(fs * duration)
    white = np.random.randn(n)
    freq = np.fft.rfftfreq(n, 1/fs)
    pink_filter = 1 / np.sqrt(freq + 1e-10)  # 1/f filter
    pink_filter[0] = 0
    white_fft = np.fft.rfft(white)
    pink_fft = white_fft * pink_filter
    pink = np.fft.irfft(pink_fft, n=n)
    return pink / np.std(pink) * 0.1  # Normalize to -20 dBFS

def generate_white_noise(fs, duration):
    n = int(fs * duration)
    white = np.random.randn(n)
    return white / np.std(white) * 0.1

def generate_swept_sine(fs, duration):
    t = np.linspace(0, duration, int(fs * duration))
    freq = np.logspace(np.log10(20), np.log10(15000), len(t))
    swept_signal = signal.chirp(t, f0=20, f1=15000, t1=duration, method='logarithmic')
    return swept_signal / np.std(swept_signal) * 0.1  # Normalize to -20 dBFS

# Simulating a test waveform
def simulate_waveform(fs, duration, test_signal, test_name):
    n = int(fs * duration)
    if test_signal == "Pink Noise":
        signal = generate_pink_noise(fs, duration)
    elif test_signal == "White Noise":
        signal = generate_white_noise(fs, duration)
    else:
        signal = generate_swept_sine(fs, duration)
    
    # Apply speaker response: ±3 dB from 50 Hz to 15 kHz, 12 dB/octave roll-off below 50 Hz
    freq = np.fft.rfftfreq(n, 1/fs)
    response = np.ones(len(freq))
    # Low-frequency roll-off (12 dB/octave = 40 dB/decade)
    low_freq_mask = (freq < 50) & (freq > 0)  # Exclude 0 Hz
    response[low_freq_mask] = 10 ** (-2 * np.log10(freq[low_freq_mask] / 50))  # -12 dB/octave
    response[freq == 0] = 1e-6  # Small value for DC component
    # ±3 dB variation
    response *= np.random.uniform(0.707, 1.412, len(freq))  # 10^(-3/20) to 10^(3/20)
    # High-frequency boost for MKH 416 (+2 dB above 8 kHz)
    high_freq_mask = freq > 8000
    response[high_freq_mask] *= 1.259  # 10^(2/20)
    
    # Ensure response is finite
    response = np.nan_to_num(response, nan=1.0, posinf=1.0, neginf=1.0)
    
    # Apply response in frequency domain
    fft_signal = np.fft.rfft(signal)
    fft_signal *= response
    signal = np.fft.irfft(fft_signal, n=n)
    
    # Add background noise (-40 dB)
    noise = np.random.randn(n) * 0.01  # -40 dB relative to signal
    signal += noise
    
    # Tailor to test item
    if "Low-Frequency" in test_name:
        # Emphasize 20-200 Hz
        fft_signal = np.fft.rfft(signal)
        high_freq_mask = freq > 200
        fft_signal[high_freq_mask] *= 0.1  # Attenuate above 200 Hz
        signal = np.fft.irfft(fft_signal, n=n)
    elif "Tweeter" in test_name:
        # Emphasize 1 kHz-15 kHz
        fft_signal = np.fft.rfft(signal)
        low_freq_mask = freq < 1000
        fft_signal[low_freq_mask] *= 0.1  # Attenuate below 1 kHz
        signal = np.fft.irfft(fft_signal, n=n)
    
    # Ensure signal is finite and normalized
    signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)
    if np.std(signal) > 0:
        signal = signal / np.std(signal) * 0.1  # Normalize to -20 dBFS
    return signal

# Capturing audio with Zoom H4n
def capture_audio(fs=48000, duration=5, input_channel=1):
    if not is_audio_interface_connected():
        st.error("Zoom H4n Pro not detected. Please connect the device or use 'Simulate Test Waveform'.")
        return np.zeros(int(fs * duration))
    try:
        channels = [input_channel]
        recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, device='Zoom H4n Pro', mapping=channels)
        sd.wait()
        return recording[:, 0]
    except Exception as e:
        st.error(f"Error capturing audio: {e}. Ensure Zoom H4n is connected and selected as input device.")
        return np.zeros(int(fs * duration))

# Processing signal with amplitude and phase adjustments
def process_signal(signal, fs, amplitude_scale, phase_shift_deg):
    processed = signal * amplitude_scale
    freq = np.fft.rfftfreq(len(signal), 1/fs)
    fft_signal = np.fft.rfft(processed)
    phase_shift_rad = np.deg2rad(phase_shift_deg)
    fft_shifted = fft_signal * np.exp(1j * phase_shift_rad)
    processed = np.fft.irfft(fft_shifted, n=len(signal))
    return processed

# Computing spectrum and phase
def compute_spectrum(signal, fs):
    if not np.any(signal) or np.any(np.isnan(signal)):
        raise ValueError("Invalid waveform: contains only zeros or NaN values")
    window = signal.hann(len(signal))  # Use scipy.signal.hann
    fft_signal = np.fft.rfft(signal * window)
    freq = np.fft.rfftfreq(len(signal), 1/fs)
    amplitude = 20 * np.log10(np.abs(fft_signal) / np.max(np.abs(fft_signal)) + 1e-10)
    phase = np.angle(fft_signal, deg=True)
    return freq, amplitude, phase

# Creating Streamlit UI
st.title("Speaker Calibration Test Procedure")

# Sidebar for test selection and hardware settings
with st.sidebar:
    st.header("Test Configuration")
    test_name = st.selectbox("Select Test Item", test_procedures['Description of the Test'])
    selected_test = test_procedures[test_procedures['Description of the Test'] == test_name].iloc[0]
    
    st.subheader("Test Details")
    st.write(f"**Item Number**: {selected_test['Item Number']}")
    st.write(f"**Setup**: {selected_test['Setup']}")
    st.write(f"**Expected Result**: {selected_test['Expected Result']}")
    st.write(f"**Remarks**: {selected_test['Remarks']}")
    
    input_channel = st.selectbox("Select Input Channel (Zoom H4n)", [1, 2, 3, 4])
    test_signal = st.selectbox("Select Test Signal", ["Pink Noise", "White Noise", "Swept Sine"])
    duration = st.slider("Recording Duration (seconds)", 1, 10, 5)

# Main panel for controls and visualization
col1, col2 = st.columns([1, 2])

with col1:
    st.header("Controls")
    amplitude_scale = st.slider("Amplitude Scale", 0.1, 2.0, 1.0, 0.1)
    phase_shift_deg = st.slider("Phase Shift (degrees)", -180, 180, 0, 5)
    
    if st.button("Capture Audio"):
        with st.spinner("Capturing audio..."):
            signal = capture_audio(fs=48000, duration=duration, input_channel=input_channel)
            if np.any(signal) and not np.any(np.isnan(signal)):
                processed_signal = process_signal(signal, 48000, amplitude_scale, phase_shift_deg)
                st.session_state.waveforms.append(processed_signal)
                st.session_state.run_count = min(st.session_state.run_count + 1, 4)
                st.success("Audio captured successfully!")
            else:
                st.error("Captured waveform is invalid (all zeros or contains NaN).")

    if st.button("Simulate Test Waveform"):
        with st.spinner("Simulating waveform..."):
            signal = simulate_waveform(fs=48000, duration=duration, test_signal=test_signal, test_name=test_name)
            if np.any(signal) and not np.any(np.isnan(signal)):
                processed_signal = process_signal(signal, 48000, amplitude_scale, phase_shift_deg)
                st.session_state.waveforms.append(processed_signal)
                st.session_state.run_count = min(st.session_state.run_count + 1, 4)
                st.success("Test waveform simulated successfully!")
            else:
                st.error("Simulated waveform is invalid (all zeros or contains NaN).")
    
    if st.button("Clear Waveforms"):
        st.session_state.waveforms = []
        st.session_state.run_count = 0
        st.success("Waveforms cleared.")

    if st.button("Play Test Signal"):
        if not is_audio_interface_connected():
            st.error("Zoom H4n Pro not detected. Please connect the device to play the test signal.")
        else:
            fs = 48000
            if test_signal == "Pink Noise":
                signal = generate_pink_noise(fs, duration)
            elif test_signal == "White Noise":
                signal = generate_white_noise(fs, duration)
            else:
                signal = generate_swept_sine(fs, duration)
            try:
                sd.play(signal, fs, device='Zoom H4n Pro')
                sd.wait()
                st.success(f"Played {test_signal} successfully!")
            except Exception as e:
                st.error(f"Error playing signal: {e}")

with col2:
    st.header("Waveform Visualization")
    if st.session_state.waveforms:
        fig_waveform = go.Figure()
        t = np.linspace(0, duration, len(st.session_state.waveforms[0]))
        for i, waveform in enumerate(st.session_state.waveforms[:4]):
            fig_waveform.add_trace(go.Scatter(
                x=t,
                y=waveform,
                mode='lines',
                name=f'Run {i+1}',
                line=dict(color=st.session_state.colors[i])
            ))
        fig_waveform.update_layout(
            title="Captured Waveforms",
            xaxis_title="Time (s)",
            yaxis_title="Amplitude",
            showlegend=True
        )
        st.plotly_chart(fig_waveform, use_container_width=True)
    else:
        st.write("No waveforms captured yet.")

    st.header("Spectrum and Phase Analysis")
    if st.session_state.waveforms:
        try:
            freq, amplitude, phase = compute_spectrum(st.session_state.waveforms[-1], 48000)
            fig_spectrum = go.Figure()
            fig_spectrum.add_trace(go.Scatter(
                x=freq,
                y=amplitude,
                mode='lines',
                name='Amplitude (dB)',
                line=dict(color='blue')
            ))
            fig_spectrum.update_layout(
                title="Frequency Spectrum",
                xaxis_title="Frequency (Hz)",
                yaxis_title="Amplitude (dB)",
                xaxis_type="log",
                xaxis_range=[np.log10(20), np.log10(15000)]
            )
            st.plotly_chart(fig_spectrum, use_container_width=True)

            fig_phase = go.Figure()
            fig_phase.add_trace(go.Scatter(
                x=freq,
                y=phase,
                mode='lines',
                name='Phase (degrees)',
                line=dict(color='red')
            ))
            fig_phase.update_layout(
                title="Phase Response",
                xaxis_title="Frequency (Hz)",
                yaxis_title="Phase (degrees)",
                xaxis_type="log",
                xaxis_range=[np.log10(20), np.log10(15000)]
            )
            st.plotly_chart(fig_phase, use_container_width=True)
        except Exception as e:
            st.error(f"Error computing spectrum: {e}. The waveform may be invalid.")
    else:
        st.write("Capture or simulate a waveform to view spectrum and phase.")